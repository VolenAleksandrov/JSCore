/**
 * Created by vo13n on 17-Jul-17.
 */
let Person = require('./person');
result.Person = Person;